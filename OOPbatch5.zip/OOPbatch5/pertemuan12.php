<?php

// static property dan static method
// digunakan saat kasus kasus tertentu karna pengunaaan nya terbatas

// untuk membuat static property dan static method, kita memakai keyword static
// keyword static setelah access modifier


// 1.
// class Latihan{
//     //static property
//     public static $namaProperty = 'Property Static';

//     //static method
//     public static function namaMethod(){
//         return 'Halo saya adalah static method';
//     }
// }

// echo Latihan::$namaProperty . "<br>";
// echo Latihan::namaMethod();


// 2.

// class Mobil{
//     private static $merk = 'toyota';

//     private static function test($text){
//         return strtoupper($text);
//     }

//     public function getMerk(){
//         $merk = self::$merk;
//         return self::test($merk);
//     }
// }

// echo Mobil::getMerk();


// 3.

// class Mobil{
//     public static $km = 0;

//     public function jalan($jarak){
//         self::$km += $jarak;
//     }
// }

// $mobil1 = new Mobil();
// $mobil1->jalan(10);
// echo Mobil::$km . "<br>";

// $mobil2 = new Mobil();
// $mobil2->jalan(5);
// echo Mobil::$km;


// 4.
class StringFormat{
    public static function lowerCase($text){
        return strtolower($text);
    }

    public static function upperCase($text){
        return strtoupper($text);
    }

    public static function titleCase($text){
        return ucwords($text);
    }
}

echo StringFormat::lowerCase('EDUTECH') . "<br>";
echo StringFormat::upperCase('web developer') . "<br>";
echo StringFormat::titleCase('frontend developer test');






