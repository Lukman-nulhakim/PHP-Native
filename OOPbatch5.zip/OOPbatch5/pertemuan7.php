<?php 

// abstract class dan abstract method
// abstract classs setidaknya harus ada minimal 1 abstract method
// abstract method adalah method yg hanya di deklarasikan dan jg di berikan di depan nama abstract itu sendiri

// abstract class sebuah class yg tidak bisa di instansiasi -> biasa di gunakan untuk kerangka dasar
// abstract method sebuah method dasar yg dapat di implementasikan berulang ulang di dalam class anak
// abstract class bisa digunakan di dalam inheritence(pewarisan)


// 1.
// abstract class BangunDatar{
//     abstract protected function hitungLuas();
// }

// class Persegi extends BangunDatar{
//     protected $sisi = 4;
    
//     public function hitungLuas(){
//         // pow adalah function untuk pangkat
//         return pow($this->sisi, 2);
//     }
// }

// class Segitiga extends BangunDatar{
//     protected $alas = 4;
//     protected $tinggi = 3;

//     public function hitungLuas(){
//         return(0.5 * $this->alas * $this->tinggi);
//     }
// }

// $persegi = new Persegi();
// echo "Luas Persegi adalah = " . $persegi->hitungLuas() . "<br>";

// $segitiga = new Segitiga();
// echo "Luas Segitiga adalah = " . $segitiga->hitungLuas();


abstract class Mobil{
    protected $volTangki;

    public function isiBensin($vol){
        $this->volTangki = $vol;
    }

    abstract protected function jarakTempuhMaksimum();
}

class Toyota extends Mobil{
    protected $perLiter = 10;

    public function jarakTempuhMaksimum(){
        $jarakMaks = $this->perLiter * $this->volTangki;
        echo 'Jarak tempuh maksimal Toyota adalah ' . $jarakMaks . " Km <br>";
    }
}

class Honda extends Mobil{
    protected $perLiter = 20;

    public function jarakTempuhMaksimum(){
        $jarakMaks = $this->perLiter * $this->volTangki;
        echo 'Jarak tempuh maksimal Honda adalah ' . $jarakMaks . " Km";
    }
}

$toyota = new Toyota();
$toyota->isiBensin(10);
$toyota->jarakTempuhMaksimum();


$honda = new Honda();
$honda->isiBensin(15);
$honda->jarakTempuhMaksimum();