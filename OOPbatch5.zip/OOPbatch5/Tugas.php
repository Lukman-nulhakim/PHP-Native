Buat folder dengan Karyawan

di dalam folder Karyawan bikin file index.php -> view(tampil)
di dalam folder Karyawan bikin folder pt
di dalam folder pt bikin file dengan Pria dan Wanita
di dalam folder pt bikin folder dengan gaji
di dalam folder gaji bikin file umr dan atasumr


contoh tampilan

Lukman tinggal di teluknaga bagian web developer gaji 100000000 -> atasumr
Gia tinggal di cipondoh bagian frontend developer gaji 45000000 -> umr