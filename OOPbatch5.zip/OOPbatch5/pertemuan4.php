<?php 

// magic method dan magic constant
// ciri-ciri magic method adalah ada nya __ (double underscore)
// __construct bakal menyeting nilai awal property -> yg bakal di proses duluan
// __destruct bakal menyeting nilai akhir property -> yg bakal di proses belakangan


// 1.
// class Mobil{

//     public function __construct(){
//         echo "Ini method construct <br>";
//     }

//     public function __destruct(){
//         echo "Ini method destruct";
//     }

//     public function mobil_saya(){
//         return "ini method yg di buat sendiri<br>";
//     }


// }

// $mobil = new Mobil();

// echo $mobil->mobil_saya();



// 2.
// class Mobil{
//     public $merk = '';

//     public function __construct($merk){
//         $this->merk = $merk;
//     }

//     public function getMerk(){
//         return "Merk mobil kamu adalah " . $this->merk;
//     }
// }

// $mobil = new Mobil('Avanza');
// echo $mobil->getMerk();



// 3.
class Mobil{
    public $merk = '';

    public function __construct($merk = 'BMW'){
        $this->merk = $merk;
    }

    public function getMerk(){
        return "Merk mobil kamu adalah " . $this->merk;
    }
}

$mobil = new Mobil();
echo $mobil->getMerk();