<?php

// polymorphism
// banyak bentuk
// method yg berada pada class berbeda yg melakukan hal yg sama,
// harus memiliki nama yg sama pula

interface BangunDatar{
    ?? (method)
}

class Persegi implements BangunDatar{
    private a ??

    public function __construct(a){

    }

    public function (method yg di baris 9 di panggil){

    }
}


class Segitiga implements BangunDatar{
    private a ??
    private b ??

    public function __construct(a, b){

    }

    public function (method yg di baris 9 di panggil){
        
    }
}

class Lingkaran implements BangunDatar{
    private a ??

    public function __construct(a){

    }

    public function (method yg di baris 9 di panggil){
        
    }
}
