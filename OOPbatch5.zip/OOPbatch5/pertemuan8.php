<?php

//interface
// membuat method tertentu yg meng-inheritence dari parent class nya
// kita bisa membuat sebuah abstract class atau interface di dalamnya

// 1.
// interface Mobil{
//     public function setMerk($merk);
//     public function getMerk();
// }

// class BMW implements Mobil{
//     private $merk;

//     public function setMerk($merk){
//         $this->merk = $merk;
//     } 

//     public function getMerk(){
//         return $this->merk;
//     }
// }

// $bmw = new BMW();
// $bmw->setMerk('BMW 132');
// echo $bmw->getMerk();



// 2.
interface Mobil{
    public function setMerk($merk);
    public function getMerk();
}

interface KendaraanBeroda{
    public function setRoda($roda);
    public function getRoda();
}

class Bmw implements Mobil, KendaraanBeroda{
    private $merk;
    private $roda;

    public function setMerk($merk){
        $this->merk = $merk;
    }

    public function getMerk(){
        return $this->merk;
    }

    public function setRoda($roda){
        $this->roda = $roda;
    }

    public function getRoda(){
        return $this->roda;
    }
}

$bmw = new Bmw();
$bmw->setMerk('BMW b-187');
$bmw->setRoda(4);
echo 'Mobil Kamu adalah = ' . $bmw->getMerk() . " Beroda " . $bmw->getRoda();