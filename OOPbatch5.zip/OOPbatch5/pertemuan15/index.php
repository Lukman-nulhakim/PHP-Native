<?php

require "src/Calculator.php";
require "src/Mobil/Mobil.php";
require "src/Mobil/Toyota.php";
require "src/Mobil/Honda.php";

use Dummy\Calculator;
use Dummy\Mobil\Toyota as Fortuner;
use Dummy\Mobil\Honda as Civic;


$toyota = new Fortuner('Toyota Fortuner', 10);
$calculator = new Calculator($toyota);
echo "Jarak Maksimum " . $toyota->getMerk() . " adalah " . $calculator->hitungJarak() . " km <br>";


$honda = new Civic('Honda Civic', 10);
$calculator = new Calculator($honda);
echo "Jarak Maksimum " . $honda->getMerk() . " adalah " . $calculator->hitungJarak() . " km <br>";

