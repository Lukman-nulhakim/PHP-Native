<?php

// type hinting
// kita gunakan untuk diterima sebagai parameter/argumen
// suatu method, dengan demikian kita bisa meningkatkan keamanan data, karna sebelumnya
// kita hanya memasukkan properti di argument/parameter dan mengisi datanya bebas (dalam arti bebas)
// ini kita bisa menggunakan type hinting, dan kita bisa atur data nya apa yg di input

//contoh rumus kita memasukkan
// function namaMethod(array $namaArray){
//     // source code
// }


// 1. array type hinting
// function hitungJarak(array $kendaraan){
//     foreach($kendaraan as $mobil){
//         $jarakMaks = $mobil[1] * $mobil[2];
//         echo $mobil[0] . " : " . $jarakMaks . "<br>";
//     }
// }


// $kendaraan = [
//     ['Toyota', 10, 25],
//     ['Suzuki', 15, 21],
//     ['Odong-odong', 5, 2]
// ];

// hitungJarak($kendaraan);



// 2. object type hinting
// class Mobil{
//     private $merk;
//     private $efisiensi;
//     private $volBbm;

//     public function __construct($merk, $efisiensi, $volBbm){
//         $this->merk = $merk;
//         $this->efisiensi = $efisiensi;
//         $this->volBbm = $volBbm;
//     }

//     public function getMerk(){
//         return $this->merk;
//     }

//     public function getEfisiensi(){
//         return $this->efisiensi;
//     }

//     public function getVolBbm(){
//         return $this->volBbm;
//     }
// }

// class Calculator{
//     public function hitungJarak(Mobil $mobil){
//         $efisiensi = $mobil->getEfisiensi();
//         $volBbm = $mobil->getVolBbm();
//         $jarakMaks = $efisiensi * $volBbm;
//         echo $mobil->getMerk() . " : " . $jarakMaks . " Km <br>";
//     }
// }

// $toyota = new Mobil('Toyota', 10, 20);
// $call = new Calculator();
// $call->hitungJarak($toyota);

// $suzuki = new Mobil('Suzuki', 15, 20);
// $muncul = new Calculator();
// $muncul->hitungJarak($suzuki);


// 3 type hinting tipe data

// native contoh
// function nama($orang){
//     if(is_string($orang)){
//         echo 'Halo ' . $orang;
//     } else{
//         echo 'Bukan String COy';
//     }
// }
// nama('rajif');



// oop contoh
class Mobil{
    private $merk;
    private $harga;
    private $lunas;
    private $jumlahPintu;

    public function setMerk(string $merk){
        $this->merk = $merk;
    }

    public function setHarga(float $harga){
        $this->harga = $harga;
        
    }
    public function setLunas(bool $lunas){
        $this->lunas = $lunas;
    }

    public function setPintu(int $pintu){
        $this->jumlahPintu = $pintu;
    }
}

$toyota = new Mobil();
$toyota->setMerk('Toyota');
$toyota->setHarga(12500000);
$toyota->setPintu(2);
$toyota->setLunas(true);
var_dump($toyota);