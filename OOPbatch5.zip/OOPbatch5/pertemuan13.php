<?php

// trait
// stytax use

// 1.
// class Mobil{
//     // Memasukkan trait
//     use TurboCharger;

//     private $merk;
//     private $hp = 300;

//     public function __construct($merk){
//         $this->merk = $merk;
//     }

//     public function getMerk(){
//         return $this->merk;
//     }

//     public function getHp(){
//         return $this->hp;
//     }
// }

// trait TurboCharger{
//     public function setHp($hp){
//         $this->hp += $hp;
//     }
// }

// $nissan = new Mobil('Nissan Skyline GTR');
// echo $nissan->getMerk() . "<br>";
// echo "Turbo : " . $nissan->getHp() . " PK <br>";
// $nissan->setHp(50);
// echo "Turbo charged : " . $nissan->getHp() . " PK";


// 2
class Mobil{
    // Memasukkan trait
    use TurboCharger;
    use Nitro;

    private $merk;
    private $hp = 300;

    public function __construct($merk){
        $this->merk = $merk;
    }

    public function getMerk(){
        return $this->merk;
    }

    public function getHp(){
        return $this->hp;
    }
}

trait TurboCharger{
    public function setHp($hp){
        $this->hp += $hp;
    }
}

trait Nitro{
    private $maksHp = 150;
    
    public function nos(){
        $this->hp += $this->maksHp;
    }

}

$nissan = new Mobil('Nissan Skyline GTR');
echo $nissan->getMerk() . "<br>";
echo "Turbo : " . $nissan->getHp() . " PK <br>";
$nissan->setHp(50);
echo "Turbo charged : " . $nissan->getHp() . " PK <br>";
$nissan->nos();
echo "Hp Nitro : " . $nissan->getHp() . "PK";