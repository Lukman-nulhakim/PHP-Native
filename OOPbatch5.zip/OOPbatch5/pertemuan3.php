<?php

// method chaining
//

// tanpa method chaining
// class Mobil{
//     public $tangki = 0;

//     public function isiBensin($liter){
//         $this->tangki += $liter;
//     }

//     public function kendaraan($jarak){
//         $terpakai = $jarak / 20;
//         $this->tangki -= $terpakai;
//     }
// }

// $mobil = new Mobil();
// $mobil->isiBensin(2);
// $mobil->kendaraan(20);
// $sisaBesin = $mobil->tangki;
// echo "Sisa bensin mobil kamu adalah " . $sisaBesin . " Liter";


// menggunakan method
class Mobil{
    public $tangki = 0;

    public function isiBensin($liter){
        $this->tangki += $liter;
        return $this;
    }

    public function kendaraan($jarak){
        $terpakai = $jarak / 20;
        $this->tangki -= $terpakai;
        return $this;
    }
}

$mobil = new Mobil();
$sisaBensin = $mobil->isiBensin(2)->kendaraan(20)->tangki;
echo "Sisa bensin mobil kamu adalah " . $sisaBensin . " Liter";

